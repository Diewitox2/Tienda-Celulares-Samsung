package PROYECTO;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;

public class ConfigurarDescuento extends JFrame {
    // Declaramos los componentes que vamos a usar en la ventana
    private JComboBox<String> comboPago;
    private JTextField txtDescuento;
    private JButton btnAplicar;
    private JButton btnCerrar;

    // Mapa din�mico para almacenar los descuentos asociados a los m�todos de pago
    private HashMap<String, Double> descuentos;

    public ConfigurarDescuento(HashMap<String, Double> descuentos) {
        this.descuentos = descuentos; // Recibimos el mapa de descuentos desde VentasCelulares

        // Configuramos la ventana
        setTitle("Configurar Descuento");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE); // Permitir cierre independiente
        setLayout(null);

        // T�tulo de la ventana
        JLabel titulo = new JLabel("Configuraci�n de Descuento");
        titulo.setFont(titulo.getFont().deriveFont(18f)); // Tama�o m�s grande para el t�tulo
        titulo.setBounds(80, 20, 250, 30); // Posici�n y tama�o
        add(titulo);

        // Etiqueta y ComboBox para seleccionar el m�todo de pago
        JLabel lblPago = new JLabel("M�todo de Pago:");
        lblPago.setBounds(30, 70, 120, 25);
        add(lblPago);

        comboPago = new JComboBox<>(descuentos.keySet().toArray(new String[0])); // Llenamos con los m�todos de pago
        comboPago.setBounds(160, 70, 200, 25);
        add(comboPago);

        // Configuramos el campo de texto para el descuento
        JLabel lblDescuento = new JLabel("Descuento (%):");
        lblDescuento.setBounds(30, 120, 120, 25);
        add(lblDescuento);

        txtDescuento = new JTextField();
        txtDescuento.setBounds(160, 120, 200, 25);
        add(txtDescuento);

        // Bot�n para aplicar el descuento
        btnAplicar = new JButton("Aplicar");
        btnAplicar.setBounds(70, 180, 100, 30);
        btnAplicar.addActionListener(e -> {
            String metodoSeleccionado = (String) comboPago.getSelectedItem();
            try {
                double nuevoDescuento = Double.parseDouble(txtDescuento.getText()) / 100; // Convertimos a porcentaje
                if (nuevoDescuento < 0 || nuevoDescuento > 1) {
                    throw new IllegalArgumentException("El descuento debe estar entre 0% y 100%");
                }
                descuentos.put(metodoSeleccionado, nuevoDescuento); // Actualizamos el descuento en el mapa
                JOptionPane.showMessageDialog(this, "Descuento aplicado correctamente.", "�xito", JOptionPane.INFORMATION_MESSAGE);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Por favor, ingrese un n�mero v�lido.", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        add(btnAplicar);

        // Bot�n para cerrar la ventana
        btnCerrar = new JButton("Cerrar");
        btnCerrar.setBounds(200, 180, 100, 30);
        btnCerrar.addActionListener(e -> dispose());
        add(btnCerrar);

        // Listener para actualizar el descuento mostrado al cambiar el m�todo de pago
        comboPago.addActionListener(e -> {
            String metodoSeleccionado = (String) comboPago.getSelectedItem();
            txtDescuento.setText(String.valueOf((int) (descuentos.get(metodoSeleccionado) * 100))); // Mostramos como porcentaje
        });

        // Mostrar el descuento inicial del primer m�todo de pago seleccionado
        comboPago.setSelectedIndex(0);
    }

    public static void main(String[] args) {
        HashMap<String, Double> descuentosPrueba = new HashMap<>();
        descuentosPrueba.put("Efectivo", 0.0);
        descuentosPrueba.put("BBVA", 0.05);
        descuentosPrueba.put("MasterCard", 0.03);
        ConfigurarDescuento ventana = new ConfigurarDescuento(descuentosPrueba);
        ventana.setVisible(true);
    }
}