package PROYECTO;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class VerificacionStockCelulares extends JFrame {
    private JLabel lblTitulo;
    private JPanel panelTarjetas;
    private JPanel panelBotones;
    private JButton btnGuardarCambios;

    // DECLARACIÓN DE VARIABLES LÓGICAS
    private String[] celulares;
    private Map<String, Boolean> stockCelulares; // Estado de stock para cada celular
    private Map<String, Integer> stockCantidad; // Cantidad de stock para cada celular

    // CONSTRUCTOR PRINCIPAL
    public VerificacionStockCelulares() {
        configurarVentana();
        inicializarComponentes();
        agregarComponentes();
    }

    // CONFIGURACIÓN DE LA VENTANA PRINCIPAL
    private void configurarVentana() {
        setResizable(false);
        setTitle("Verificación de Stock de Celulares");
        setSize(600, 700); // Ampliar el tamaño de la ventana
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(240, 245, 255));
        getContentPane().setLayout(new BorderLayout());
    }

    // INICIALIZACIÓN DE COMPONENTES
    private void inicializarComponentes() {
        // Título
        lblTitulo = new JLabel("📦 Verificación de Stock de Celulares", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitulo.setForeground(new Color(0, 70, 140));
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(15, 0, 10, 0));

        // Panel de tarjetas
        panelTarjetas = new JPanel();
        panelTarjetas.setLayout(new BoxLayout(panelTarjetas, BoxLayout.Y_AXIS));
        panelTarjetas.setBackground(new Color(240, 245, 255));

        // Lista de celulares
        celulares = new String[]{
            "Galaxy S23 Ultra;Samsung;$1199;6.8\";12GB;512GB;5000mAh;108MP;Android 13",
            "Galaxy A54;Samsung;$449;6.4\";8GB;128GB;5000mAh;50MP;Android 13",
            "Galaxy Z Fold5;Samsung;$1799;7.6\";12GB;512GB;4400mAh;50MP;Android 13",
            "Galaxy S24+;Samsung;$999;6.7\";12GB;256GB;4900mAh;50MP;Android 14",
            "Galaxy A15 5G;Samsung;$199;6.5\";4GB;128GB;5000mAh;50MP;Android 14"
        };

        // Estado inicial del stock
        stockCelulares = new HashMap<>();
        stockCantidad = new HashMap<>();
        inicializarStockCelulares(0);

        // Crear tarjetas sin usar bucles
        crearTarjetasRecursivas(0);

        // Botón guardar cambios
        panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 30, 10));
        panelBotones.setBackground(new Color(240, 245, 255));
        btnGuardarCambios = new JButton("Guardar Cambios");
        configurarBoton(btnGuardarCambios);
        btnGuardarCambios.addActionListener(e -> guardarCambios()); // Acción al guardar cambios
    }

    // MÉTODO PARA AGREGAR COMPONENTES A LA VENTANA
    private void agregarComponentes() {
        getContentPane().add(lblTitulo, BorderLayout.NORTH);

        JScrollPane scrollPane = new JScrollPane(panelTarjetas);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        getContentPane().add(scrollPane, BorderLayout.CENTER);

        panelBotones.add(btnGuardarCambios);
        getContentPane().add(panelBotones, BorderLayout.SOUTH);
    }

    // MÉTODO RECURSIVO PARA INICIALIZAR EL ESTADO DEL STOCK
    private void inicializarStockCelulares(int index) {
        if (index >= celulares.length) return;
        String modelo = celulares[index].split(";")[0]; // Extraer el modelo del celular
        stockCelulares.put(modelo, true);  // Inicialmente, todos tienen stock
        stockCantidad.put(modelo, 10); // Inicialmente, todos tienen 10 unidades de stock
        inicializarStockCelulares(index + 1);
    }

    // MÉTODO RECURSIVO PARA CREAR TARJETAS
    private void crearTarjetasRecursivas(int index) {
        if (index >= celulares.length) return;

        String datos = celulares[index];
        panelTarjetas.add(crearTarjeta(datos));
        panelTarjetas.add(Box.createRigidArea(new Dimension(0, 20))); // Espacio entre tarjetas

        crearTarjetasRecursivas(index + 1);
    }

    // MÉTODO PARA CREAR UNA TARJETA
    private JPanel crearTarjeta(String datos) {
        String[] d = datos.split(";");
        String modelo = d[0]; // Modelo del celular

        JPanel tarjeta = new JPanel();
        tarjeta.setLayout(new BorderLayout());
        tarjeta.setBackground(Color.WHITE);
        tarjeta.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 220, 250)),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));

        // Panel izquierdo con información del celular
        JPanel panelInfo = new JPanel();
        panelInfo.setLayout(new BoxLayout(panelInfo, BoxLayout.Y_AXIS));
        panelInfo.setBackground(Color.WHITE);

        JLabel[] etiquetas = {
            new JLabel("Modelo: " + d[0]),
            new JLabel("Marca: " + d[1]),
            new JLabel("Precio: " + d[2]),
            new JLabel("Pantalla: " + d[3]),
            new JLabel("RAM: " + d[4]),
            new JLabel("Almacenamiento: " + d[5]),
            new JLabel("Batería: " + d[6]),
            new JLabel("Cámara: " + d[7]),
            new JLabel("Sistema Operativo: " + d[8])
        };

        for (JLabel etiqueta : etiquetas) {
            etiqueta.setFont(new Font("Segoe UI", Font.PLAIN, 13));
            panelInfo.add(etiqueta);
        }

        // Panel derecho con checkbox y campo de stock
        JPanel panelDerecho = new JPanel();
        panelDerecho.setLayout(new BoxLayout(panelDerecho, BoxLayout.Y_AXIS));
        panelDerecho.setBackground(Color.WHITE);

        JCheckBox checkBoxStock = new JCheckBox("En Stock");
        checkBoxStock.setSelected(stockCelulares.get(modelo));
        checkBoxStock.setBackground(Color.WHITE);

        JTextField txtStockCantidad = new JTextField(String.valueOf(stockCantidad.get(modelo))); // Inicialmente 10 unidades de stock
        txtStockCantidad.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtStockCantidad.setHorizontalAlignment(JTextField.CENTER);
        txtStockCantidad.setMaximumSize(new Dimension(80, 25));
        txtStockCantidad.setEnabled(!checkBoxStock.isSelected()); // Habilitar/deshabilitar según el estado del checkbox

        checkBoxStock.addActionListener(e -> {
            boolean enStock = checkBoxStock.isSelected();
            stockCelulares.put(modelo, enStock);
            txtStockCantidad.setEnabled(!enStock); // Habilitar campo solo si el checkbox no está seleccionado
        });

        panelDerecho.add(txtStockCantidad);
        panelDerecho.add(Box.createRigidArea(new Dimension(0, 10)));
        panelDerecho.add(checkBoxStock);

        tarjeta.add(panelInfo, BorderLayout.CENTER);
        tarjeta.add(panelDerecho, BorderLayout.EAST);

        return tarjeta;
    }

    // MÉTODO PARA CONFIGURAR BOTONES
    private void configurarBoton(JButton boton) {
        boton.setBackground(new Color(0, 95, 180));
        boton.setForeground(Color.WHITE);
        boton.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        boton.setFocusPainted(false);
        boton.setPreferredSize(new Dimension(150, 30));
    }

    // MÉTODO PARA GUARDAR CAMBIOS
    private void guardarCambios() {
        StringBuilder mensaje = new StringBuilder("Estado del stock:\n");
        for (String modelo : stockCelulares.keySet()) {
            boolean enStock = stockCelulares.get(modelo);
            int cantidadStock = stockCantidad.get(modelo);
            mensaje.append(modelo).append(": ")
                .append(enStock ? "En stock (" + cantidadStock + " unidades)" : "Sin stock")
                .append("\n");
        }
        JOptionPane.showMessageDialog(this, mensaje.toString(), "Cambios Guardados", JOptionPane.INFORMATION_MESSAGE);
    }

    // MÉTODO PRINCIPAL PARA PROBAR LA INTERFAZ
    public static void main(String[] args) {
        VerificacionStockCelulares ventana = new VerificacionStockCelulares();
        ventana.setVisible(true);
    }
}