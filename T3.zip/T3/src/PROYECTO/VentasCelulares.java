package PROYECTO;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.HashMap;

public class VentasCelulares extends JFrame {
    private JPanel panelPrincipal;
    private JLabel lblTitulo, lblNombreCliente, lblModeloCelular, lblMetodoPago, lblCantidad, lblPrecio;
    private JTextField txtNombreCliente, txtCantidad;
    private JComboBox<String> comboModelo, comboPago;
    private JButton btnVender, btnLimpiar, btnConfigurarObsequios, btnConfigurarDescuento;
    private JTextArea areaBoleta;
    private JScrollPane scrollPane;

    private int totalVentas = 0;
    private double importeAcumulado = 0;
    private static final double CUOTA_DIARIA = 20000.0;

    private final String[] modelos = {"Galaxy S23 Ultra", "Galaxy A54", "Galaxy Z Fold5", "Galaxy A15", "Galaxy S24+"};
    private final double[] precios = {4899.0, 1499.0, 7999.0, 699.0, 4299.0};
    private final int[] stock = {10, 20, 5, 15, 8};

    private final String[] metodosPago = {"Efectivo", "BBVA", "MasterCard"};
    private HashMap<String, Double> descuentos;

    private ConfigurarObsequios configurarObsequios;
    private ConfigurarDescuento configurarDescuento;

    private HashMap<String, String> obsequios;

    public VentasCelulares() {
        setTitle("Ventas de Celulares");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 600, 550);
        panelPrincipal = new JPanel();
        panelPrincipal.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(panelPrincipal);
        panelPrincipal.setLayout(null);

        descuentos = new HashMap<>();
        descuentos.put("Efectivo", 0.0);
        descuentos.put("BBVA", 0.05);
        descuentos.put("MasterCard", 0.03);

        obsequios = new HashMap<>();
        obsequios.put("1-2", "Audífonos Samsung");
        obsequios.put("3-4", "PowerBank");
        obsequios.put("5+", "SmartWatch");

        lblTitulo = new JLabel("Ventas de Celulares");
        lblTitulo.setFont(new Font("Tahoma", Font.BOLD, 22));
        lblTitulo.setBounds(200, 10, 300, 30);
        panelPrincipal.add(lblTitulo);

        lblNombreCliente = new JLabel("Nombre del Cliente:");
        lblNombreCliente.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblNombreCliente.setBounds(30, 50, 200, 25);
        panelPrincipal.add(lblNombreCliente);

        txtNombreCliente = new JTextField();
        txtNombreCliente.setFont(new Font("Tahoma", Font.PLAIN, 16));
        txtNombreCliente.setBounds(220, 50, 300, 30);
        panelPrincipal.add(txtNombreCliente);

        lblModeloCelular = new JLabel("Modelo de Celular:");
        lblModeloCelular.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblModeloCelular.setBounds(30, 100, 200, 25);
        panelPrincipal.add(lblModeloCelular);

        comboModelo = new JComboBox<>(modelos);
        comboModelo.setFont(new Font("Tahoma", Font.PLAIN, 16));
        comboModelo.setBounds(220, 100, 300, 30);
        comboModelo.addActionListener(e -> actualizarPrecio());
        panelPrincipal.add(comboModelo);

        lblPrecio = new JLabel("Precio (unidad): S/0.00");
        lblPrecio.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblPrecio.setBounds(220, 140, 300, 25);
        panelPrincipal.add(lblPrecio);

        lblCantidad = new JLabel("Cantidad:");
        lblCantidad.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblCantidad.setBounds(30, 190, 200, 25);
        panelPrincipal.add(lblCantidad);

        txtCantidad = new JTextField();
        txtCantidad.setFont(new Font("Tahoma", Font.PLAIN, 16));
        txtCantidad.setBounds(220, 190, 300, 30);
        panelPrincipal.add(txtCantidad);

        lblMetodoPago = new JLabel("Método de Pago:");
        lblMetodoPago.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblMetodoPago.setBounds(30, 240, 200, 25);
        panelPrincipal.add(lblMetodoPago);

        comboPago = new JComboBox<>(metodosPago);
        comboPago.setFont(new Font("Tahoma", Font.PLAIN, 16));
        comboPago.setBounds(220, 240, 300, 30);
        panelPrincipal.add(comboPago);

        btnVender = new JButton("Vender");
        btnVender.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnVender.setBounds(120, 290, 120, 40);
        btnVender.addActionListener(this::realizarVenta);
        panelPrincipal.add(btnVender);

        btnLimpiar = new JButton("Limpiar");
        btnLimpiar.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnLimpiar.setBounds(250, 290, 120, 40);
        btnLimpiar.addActionListener(this::limpiarCampos);
        panelPrincipal.add(btnLimpiar);

        btnConfigurarObsequios = new JButton("Configurar Obsequios");
        btnConfigurarObsequios.setFont(new Font("Tahoma", Font.BOLD, 14));
        btnConfigurarObsequios.setBounds(380, 290, 180, 40);
        btnConfigurarObsequios.addActionListener(e -> {
            if (configurarObsequios == null) {
                configurarObsequios = new ConfigurarObsequios();
                configurarObsequios.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            }
            configurarObsequios.setVisible(true);
        });
        panelPrincipal.add(btnConfigurarObsequios);

        btnConfigurarDescuento = new JButton("Configurar Descuento");
        btnConfigurarDescuento.setFont(new Font("Tahoma", Font.BOLD, 14));
        btnConfigurarDescuento.setBounds(380, 340, 180, 40);
        btnConfigurarDescuento.addActionListener(e -> {
            if (configurarDescuento == null) {
                configurarDescuento = new ConfigurarDescuento(descuentos);
                configurarDescuento.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            }
            configurarDescuento.setVisible(true);
        });
        panelPrincipal.add(btnConfigurarDescuento);

        scrollPane = new JScrollPane();
        scrollPane.setBounds(30, 400, 520, 100);
        panelPrincipal.add(scrollPane);

        areaBoleta = new JTextArea();
        areaBoleta.setFont(new Font("Monospaced", Font.PLAIN, 16));
        areaBoleta.setEditable(false);
        scrollPane.setViewportView(areaBoleta);

        actualizarPrecio();
    }

    private void actualizarPrecio() {
        int modeloIndex = comboModelo.getSelectedIndex();
        lblPrecio.setText("Precio (unidad): S/" + precios[modeloIndex]);
    }

    private void realizarVenta(java.awt.event.ActionEvent e) {
        String cliente, obsequio, mensaje, titulo;
        int cantidad, modeloIndex, metodoPagoIndex;
        double precioUnidad, subtotal, descuento, total;

        cliente = txtNombreCliente.getText().trim();
        modeloIndex = comboModelo.getSelectedIndex();
        metodoPagoIndex = comboPago.getSelectedIndex();

        if (cliente.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, ingrese el nombre del cliente 😊.", "Información requerida", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            cantidad = Integer.parseInt(txtCantidad.getText());
            if (cantidad <= 0) {
                throw new IllegalArgumentException("La cantidad debe ser mayor a 0.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Por favor, ingrese una cantidad válida 😊.", "Información requerida", JOptionPane.WARNING_MESSAGE);
            return;
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Información requerida", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (cantidad > stock[modeloIndex]) {
            mensaje = "Stock insuficiente. Disponible: " + stock[modeloIndex];
            JOptionPane.showMessageDialog(this, mensaje, "Información requerida", JOptionPane.WARNING_MESSAGE);
            return;
        }

        precioUnidad = precios[modeloIndex];
        subtotal = precioUnidad * cantidad;
        descuento = subtotal * descuentos.get(metodosPago[metodoPagoIndex]);
        total = subtotal - descuento;

        stock[modeloIndex] -= cantidad;
        totalVentas++;
        importeAcumulado += total;

        obsequio = obtenerObsequio(cantidad);

        areaBoleta.setText(
            "📄 BOLETA DE VENTA\n\n" +
            "👤 Cliente: " + cliente + "\n" +
            "📱 Modelo: " + modelos[modeloIndex] + "\n" +
            "💳 Método de Pago: " + metodosPago[metodoPagoIndex] + "\n" +
            "🔢 Cantidad: " + cantidad + "\n" +
            "🎁 Obsequio: " + obsequio + "\n" +
            "💰 Subtotal: S/" + subtotal + "\n" +
            "🔖 Descuento: S/" + descuento + "\n" +
            "💵 Total a Pagar: S/" + total + "\n"
        );

        verificarCuotaDiaria();
    }

    private String obtenerObsequio(int cantidad) {
        if (cantidad >= 5) {
            return obsequios.getOrDefault("5+", "Sin obsequio");
        } else if (cantidad >= 3) {
            return obsequios.getOrDefault("3-4", "Sin obsequio");
        } else if (cantidad >= 1) {
            return obsequios.getOrDefault("1-2", "Sin obsequio");
        }
        return "Sin obsequio";
    }

    private void verificarCuotaDiaria() {
        MensajeAlertaResumen resumen = new MensajeAlertaResumen(totalVentas, importeAcumulado, CUOTA_DIARIA);
        resumen.setVisible(true);
    }

    private void limpiarCampos(java.awt.event.ActionEvent e) {
        txtNombreCliente.setText("");
        txtCantidad.setText("");
        comboModelo.setSelectedIndex(0);
        comboPago.setSelectedIndex(0);
        lblPrecio.setText("Precio (unidad): S/0.00");
        areaBoleta.setText("");
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            VentasCelulares frame = new VentasCelulares();
            frame.setVisible(true);
        });
    }
}