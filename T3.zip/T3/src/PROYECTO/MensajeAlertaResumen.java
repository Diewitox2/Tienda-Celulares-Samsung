package PROYECTO;

import javax.swing.*;
import java.awt.*;

public class MensajeAlertaResumen extends JFrame {

    // DECLARACIÓN DE COMPONENTES
    private JLabel lblVentas;
    private JLabel lblImporte;
    private JLabel lblPorcentaje;
    private JLabel lblCuota;
    private JButton btnCerrar;

    // CONSTRUCTOR PRINCIPAL
    public MensajeAlertaResumen(int ventas, double acumulado, double cuota) {
        setResizable(false);
        configurarVentana();
        inicializarComponentes();
        inicializarLogica(ventas, acumulado, cuota);
    }

    // CONFIGURACIÓN DE LA VENTANA
    private void configurarVentana() {
        setTitle("Resumen de Ventas");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(240, 245, 255)); // Fondo azul claro
    }

    // INICIALIZACIÓN DE COMPONENTES
    private void inicializarComponentes() {
        // Título
        JLabel titulo = new JLabel("📊 Resumen de Ventas", SwingConstants.CENTER);
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titulo.setForeground(new Color(0, 70, 140)); // Azul Samsung
        titulo.setBorder(BorderFactory.createEmptyBorder(20, 10, 10, 10));
        getContentPane().add(titulo, BorderLayout.NORTH);

        // Panel de datos
        JPanel panelDatos = new JPanel();
        panelDatos.setLayout(new GridLayout(4, 1, 10, 10));
        panelDatos.setBackground(new Color(240, 245, 255)); // Fondo azul claro
        panelDatos.setBorder(BorderFactory.createEmptyBorder(10, 30, 10, 30));

        lblVentas = new JLabel("", SwingConstants.LEFT);
        lblVentas.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        lblVentas.setForeground(new Color(40, 60, 90)); // Azul oscuro
        panelDatos.add(lblVentas);

        lblImporte = new JLabel("", SwingConstants.LEFT);
        lblImporte.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        lblImporte.setForeground(new Color(40, 60, 90)); // Azul oscuro
        panelDatos.add(lblImporte);

        lblPorcentaje = new JLabel("", SwingConstants.LEFT);
        lblPorcentaje.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        lblPorcentaje.setForeground(new Color(40, 60, 90)); // Azul oscuro
        panelDatos.add(lblPorcentaje);

        lblCuota = new JLabel("", SwingConstants.LEFT);
        lblCuota.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        lblCuota.setForeground(new Color(40, 60, 90)); // Azul oscuro
        panelDatos.add(lblCuota);

        getContentPane().add(panelDatos, BorderLayout.CENTER);

        // Botón cerrar
        btnCerrar = new JButton("Cerrar");
        btnCerrar.setPreferredSize(new Dimension(100, 30));
        btnCerrar.setBackground(new Color(110, 135, 180)); // Azul Samsung
        btnCerrar.setForeground(Color.WHITE);
        btnCerrar.setFocusPainted(false);
        btnCerrar.addActionListener(e -> dispose());

        JPanel panelBoton = new JPanel();
        panelBoton.setBackground(new Color(240, 245, 255)); // Fondo azul claro
        panelBoton.add(btnCerrar);
        getContentPane().add(panelBoton, BorderLayout.SOUTH);
    }

    // MÉTODO PARA CONFIGURAR LOS DATOS
    private void inicializarLogica(int ventas, double acumulado, double cuota) {
        // Calcular porcentaje de la cuota diaria
        double porcentaje = (acumulado / cuota) * 100;

        // Asignar valores a las etiquetas
        lblVentas.setText("Total de Ventas: " + ventas);
        lblImporte.setText("Importe Acumulado: S/" + ((int) (acumulado * 100) / 100.0));
        lblPorcentaje.setText("Porcentaje de Cuota Diaria: " + ((int) (porcentaje * 100) / 100.0) + "%");
        lblCuota.setText("Meta Diaria: S/" + ((int) (cuota * 100) / 100.0));
    }

    // MÉTODO PRINCIPAL PARA PROBAR LA INTERFAZ
    public static void main(String[] args) {
        MensajeAlertaResumen ventana = new MensajeAlertaResumen(50, 12500.50, 15000.00);
        ventana.setVisible(true);
    }
}