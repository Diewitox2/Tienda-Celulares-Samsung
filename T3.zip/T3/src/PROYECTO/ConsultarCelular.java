package PROYECTO;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ConsultarCelular extends JFrame {

    // Declaramos los componentes que vamos a usar en la ventana
    private JComboBox<String> comboModelos;
    private JTextField txtPrecio;
    private JTextField txtPantalla;
    private JTextField txtRam;
    private JTextField txtAlmacenamiento;
    private JTextField txtBateria;
    private JTextField txtCamara;
    private JTextField txtSO;
    private JButton btnCerrar;

    public ConsultarCelular() {
        // Configuramos la ventana
        setTitle("Consultar Celular");
        setSize(400, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null); // Esto nos permite colocar los componentes donde queramos

        // T�tulo de la ventana
        JLabel titulo = new JLabel("Consulta de celular");
        titulo.setFont(titulo.getFont().deriveFont(20f)); // Tama�o m�s grande para el t�tulo
        titulo.setBounds(110, 20, 250, 30); // Posici�n y tama�o
        add(titulo); // Lo agregamos a la ventana

        // Etiqueta y ComboBox para seleccionar el modelo
        JLabel lblModelo = new JLabel("Modelo:");
        lblModelo.setBounds(30, 70, 100, 25); // Posici�n y tama�o
        add(lblModelo); // Lo agregamos a la ventana

        comboModelos = new JComboBox<>();
        comboModelos.setBounds(140, 70, 200, 25); // Posici�n y tama�o
        add(comboModelos); // Lo agregamos a la ventana

        // Llenamos el ComboBox con los nombres de los modelos
        comboModelos.addItem("Galaxy S23 Ultra");
        comboModelos.addItem("Galaxy Z Fold4");
        comboModelos.addItem("Galaxy A54");
        comboModelos.addItem("Galaxy A73");
        comboModelos.addItem("Galaxy S22+"); // Nuevo modelo
        comboModelos.addItem("Galaxy Z Flip5"); // Nuevo modelo
        comboModelos.addItem("Galaxy M14 5G"); // Nuevo modelo

        // Configuramos los campos de texto y etiquetas
        JLabel lblPrecio = new JLabel("Precio:");
        lblPrecio.setBounds(30, 110, 100, 25);
        add(lblPrecio);
        txtPrecio = new JTextField();
        txtPrecio.setBounds(140, 110, 200, 25);
        txtPrecio.setEditable(false);
        add(txtPrecio);

        JLabel lblPantalla = new JLabel("Pantalla:");
        lblPantalla.setBounds(30, 150, 100, 25);
        add(lblPantalla);
        txtPantalla = new JTextField();
        txtPantalla.setBounds(140, 150, 200, 25);
        txtPantalla.setEditable(false);
        add(txtPantalla);

        JLabel lblRam = new JLabel("RAM:");
        lblRam.setBounds(30, 190, 100, 25);
        add(lblRam);
        txtRam = new JTextField();
        txtRam.setBounds(140, 190, 200, 25);
        txtRam.setEditable(false);
        add(txtRam);

        JLabel lblAlmacenamiento = new JLabel("Almacenamiento:");
        lblAlmacenamiento.setBounds(30, 230, 120, 25);
        add(lblAlmacenamiento);
        txtAlmacenamiento = new JTextField();
        txtAlmacenamiento.setBounds(140, 230, 200, 25);
        txtAlmacenamiento.setEditable(false);
        add(txtAlmacenamiento);

        JLabel lblBateria = new JLabel("Bater�a:");
        lblBateria.setBounds(30, 270, 100, 25);
        add(lblBateria);
        txtBateria = new JTextField();
        txtBateria.setBounds(140, 270, 200, 25);
        txtBateria.setEditable(false);
        add(txtBateria);

        JLabel lblCamara = new JLabel("C�mara:");
        lblCamara.setBounds(30, 310, 100, 25);
        add(lblCamara);
        txtCamara = new JTextField();
        txtCamara.setBounds(140, 310, 200, 25);
        txtCamara.setEditable(false);
        add(txtCamara);

        JLabel lblSO = new JLabel("Sistema Operativo:");
        lblSO.setBounds(30, 350, 120, 25);
        add(lblSO);
        txtSO = new JTextField();
        txtSO.setBounds(140, 350, 200, 25);
        txtSO.setEditable(false);
        add(txtSO);

        // Bot�n para cerrar la ventana
        btnCerrar = new JButton("Cerrar");
        btnCerrar.setBounds(150, 420, 100, 30); // Posici�n y tama�o
        add(btnCerrar); // Lo agregamos a la ventana

        // Acci�n del bot�n cerrar
        btnCerrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); // Cierra la ventana
            }
        });

        // Acci�n cuando seleccionamos un modelo en el ComboBox
        comboModelos.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String modeloSeleccionado = (String) comboModelos.getSelectedItem();
                mostrarDatosModelo(modeloSeleccionado);
            }
        });
    }

    // M�todo para mostrar los datos de cada modelo
    private void mostrarDatosModelo(String modelo) {
        if (modelo.equals("Galaxy S23 Ultra")) {
            txtPrecio.setText("4,999.00");
            txtPantalla.setText("6.8 pulgadas");
            txtRam.setText("12 GB");
            txtAlmacenamiento.setText("256 GB");
            txtBateria.setText("5000 mAh");
            txtCamara.setText("200 MP");
            txtSO.setText("Android 13");
        } else if (modelo.equals("Galaxy Z Fold4")) {
            txtPrecio.setText("7,499.00");
            txtPantalla.setText("7.6 pulgadas");
            txtRam.setText("12 GB");
            txtAlmacenamiento.setText("512 GB");
            txtBateria.setText("4400 mAh");
            txtCamara.setText("50 MP");
            txtSO.setText("Android 13");
        } else if (modelo.equals("Galaxy A54")) {
            txtPrecio.setText("1,999.00");
            txtPantalla.setText("6.4 pulgadas");
            txtRam.setText("8 GB");
            txtAlmacenamiento.setText("128 GB");
            txtBateria.setText("5000 mAh");
            txtCamara.setText("50 MP");
            txtSO.setText("Android 13");
        } else if (modelo.equals("Galaxy A73")) {
            txtPrecio.setText("2,399.00");
            txtPantalla.setText("6.7 pulgadas");
            txtRam.setText("8 GB");
            txtAlmacenamiento.setText("256 GB");
            txtBateria.setText("5000 mAh");
            txtCamara.setText("108 MP");
            txtSO.setText("Android 12");
        } else if (modelo.equals("Galaxy S22+")) {
            txtPrecio.setText("3,899.00");
            txtPantalla.setText("6.6 pulgadas");
            txtRam.setText("8 GB");
            txtAlmacenamiento.setText("128 GB");
            txtBateria.setText("4500 mAh");
            txtCamara.setText("50 MP");
            txtSO.setText("Android 12");
        } else if (modelo.equals("Galaxy Z Flip5")) {
            txtPrecio.setText("5,499.00");
            txtPantalla.setText("6.7 pulgadas");
            txtRam.setText("8 GB");
            txtAlmacenamiento.setText("256 GB");
            txtBateria.setText("3700 mAh");
            txtCamara.setText("12 MP");
            txtSO.setText("Android 13");
        } else if (modelo.equals("Galaxy M14 5G")) {
            txtPrecio.setText("1,199.00");
            txtPantalla.setText("6.6 pulgadas");
            txtRam.setText("6 GB");
            txtAlmacenamiento.setText("128 GB");
            txtBateria.setText("6000 mAh");
            txtCamara.setText("50 MP");
            txtSO.setText("Android 13");
        }
    }

    // M�todo principal para ejecutar el programa
    public static void main(String[] args) {
        ConsultarCelular ventana = new ConsultarCelular();
        ventana.setVisible(true); // Hacemos visible la ventana
    }
}