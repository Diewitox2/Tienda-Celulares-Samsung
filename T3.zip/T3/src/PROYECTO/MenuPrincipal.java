package PROYECTO;

import java.awt.EventQueue;
import java.awt.Window;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class MenuPrincipal extends JFrame {

    private JPanel contentPane;
    private JLabel titulo;
    private JLabel logo;
    private JButton btnConsultar;
    private JButton btnActualizar;
    private JButton btnListar;
    private JButton btnVender;
    private JButton btnAcercaDe;
    private JButton btnSalir;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                MenuPrincipal frame = new MenuPrincipal();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public MenuPrincipal() {
        setTitle("Sistema de Gesti�n de Celulares");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 600, 600);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // T�tulo
        titulo = new JLabel("Sistema de Gesti�n de Casos", SwingConstants.CENTER);
        titulo.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 20));
        titulo.setBounds(100, 20, 400, 30);
        contentPane.add(titulo);

        // Logo
        logo = new JLabel();
        logo.setHorizontalAlignment(SwingConstants.CENTER);
        logo.setBounds(150, 70, 300, 100);
        logo.setIcon(new ImageIcon(getClass().getResource("/Images/logo.png")));
        contentPane.add(logo);

        // Bot�n Consultar
        btnConsultar = new JButton("Consultar");
        btnConsultar.setBounds(50, 200, 200, 30);
        btnConsultar.addActionListener(e -> abrirVentana(new ConsultarCelular()));
        contentPane.add(btnConsultar);

        // Bot�n Actualizar
        btnActualizar = new JButton("Actualizar");
        btnActualizar.setBounds(300, 200, 200, 30);
        btnActualizar.addActionListener(e -> abrirVentana(new ActualizarCelular()));
        contentPane.add(btnActualizar);

        // Bot�n Listar
        btnListar = new JButton("Listar");
        btnListar.setBounds(50, 250, 200, 30);
        btnListar.addActionListener(e -> abrirVentana(new VerificacionStockCelulares()));
        contentPane.add(btnListar);

        // Bot�n Vender
        btnVender = new JButton("Vender");
        btnVender.setBounds(300, 250, 200, 30);
        btnVender.addActionListener(e -> abrirVentana(new VentasCelulares()));
        contentPane.add(btnVender);

        // Bot�n Acerca de
        btnAcercaDe = new JButton("Acerca de");
        btnAcercaDe.setBounds(50, 300, 200, 30);
        btnAcercaDe.addActionListener(e -> abrirVentana(new AcercaDeTienda(this)));
        contentPane.add(btnAcercaDe);

        // Bot�n Salir
        btnSalir = new JButton("Salir");
        btnSalir.setBounds(300, 300, 200, 30);
        btnSalir.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this,
                    "�Seguro que quieres salir?",
                    "Confirmar salida",
                    JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                System.exit(0);
            }
        });
        contentPane.add(btnSalir);
    }

    /**
     * M�todo gen�rico para abrir cualquier ventana (JFrame o JDialog) sin cerrar la app entera.
     */
    private void abrirVentana(Window ventana) {
        if (ventana instanceof JFrame) {
            ((JFrame) ventana).setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        } else if (ventana instanceof JDialog) {
            ((JDialog) ventana).setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        }
        ventana.setVisible(true);
    }
}
