
package PROYECTO;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.io.InputStream;

public class AcercaDeTienda extends JDialog {
    public AcercaDeTienda(JFrame parent) {
        super(parent, "Acerca de Samsung Employeds", true); // T�tulo y modal
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        setSize(450, 430);
        setLocationRelativeTo(parent);
        getContentPane().setLayout(null);

        // Cargar recurso desde carpeta resources
        ImageIcon iconoVentana = null;
        try (InputStream is = getClass().getResourceAsStream("/Images/logo.png")) {
            if (is != null) {
                Image img = ImageIO.read(is);
                iconoVentana = new ImageIcon(img);
                setIconImage(img);
            } else {
                System.err.println("Recurso logo.png no encontrado");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Logo en la esquina superior izquierda
        if (iconoVentana != null) {
            JLabel lblIconoTitulo = new JLabel(
                    new ImageIcon(
                            iconoVentana.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH)
                    )
            );
            lblIconoTitulo.setBounds(20, 10, 50, 50);
            getContentPane().add(lblIconoTitulo);
        }

        // T�tulo Samsung Employeds
        JLabel lblTitulo = new JLabel("Samsung Employeds", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitulo.setBounds(80, 20, 300, 30);
        getContentPane().add(lblTitulo);

        // L�nea divisoria
        JSeparator separator = new JSeparator();
        separator.setBounds(50, 100, 350, 1);
        getContentPane().add(separator);

        // Etiqueta de autores
        JLabel lblAutores = new JLabel("Autores", SwingConstants.CENTER);
        lblAutores.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblAutores.setBounds(175, 110, 100, 20);
        getContentPane().add(lblAutores);

        // Lista de autores
        JTextArea txtAutores = new JTextArea(
                "Diego Renato Alcantara Delgadillo\n" +
                "Brayan Saul Calzada Tinta\n" +
                "Francesco Carlos Ayala Barrera"
        );
        txtAutores.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtAutores.setEditable(false);
        txtAutores.setOpaque(false);
        txtAutores.setBounds(125, 140, 200, 60);
        getContentPane().add(txtAutores);

        // Versi�n en la esquina inferior izquierda
        JLabel lblVersion = new JLabel("Versi�n 2.0");
        lblVersion.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblVersion.setBounds(10, 360, 100, 20);
        getContentPane().add(lblVersion);

        // Bot�n cerrar
        JButton btnCerrar = new JButton("Cerrar");
        btnCerrar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnCerrar.setBackground(new Color(0, 70, 140));
        btnCerrar.setForeground(Color.WHITE);
        btnCerrar.setBounds(175, 300, 100, 30);
        btnCerrar.addActionListener(e -> dispose());
        getContentPane().add(btnCerrar);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame dummyParent = new JFrame();
            dummyParent.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            AcercaDeTienda dialog = new AcercaDeTienda(dummyParent);
            dialog.setVisible(true);
        });
    }
}