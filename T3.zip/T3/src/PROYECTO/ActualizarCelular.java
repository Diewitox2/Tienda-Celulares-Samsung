package PROYECTO;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ActualizarCelular extends JFrame {

    // Declaramos los componentes que vamos a usar en la ventana
    private JComboBox<String> comboModelos;
    private JTextField txtPrecio;
    private JTextField txtPantalla;
    private JTextField txtRam;
    private JTextField txtAlmacenamiento;
    private JTextField txtBateria;
    private JTextField txtCamara;
    private JTextField txtSO;
    private JButton btnActualizar;
    private JButton btnCerrar;

    // Datos predeterminados de los celulares
    private final String[][] datosPredeterminados = {
        {"Galaxy S23 Ultra", "1199", "6.8 pulgadas", "12GB", "512GB", "5000mAh", "108MP", "Android 13"},
        {"Galaxy Z Fold4", "1799", "7.6 pulgadas", "12GB", "1TB", "4400mAh", "50MP", "Android 12L"},
        {"Galaxy A54", "449", "6.4 pulgadas", "8GB", "128GB", "5000mAh", "50MP", "Android 13"},
        {"Galaxy A73", "499", "6.7 pulgadas", "8GB", "256GB", "5000mAh", "108MP", "Android 12"},
        {"Galaxy S22+", "999", "6.6 pulgadas", "8GB", "256GB", "4500mAh", "50MP", "Android 13"},
        {"Galaxy Z Flip5", "1099", "6.7 pulgadas", "8GB", "256GB", "3700mAh", "12MP", "Android 13"},
        {"Galaxy M14 5G", "199", "6.6 pulgadas", "4GB", "128GB", "6000mAh", "50MP", "Android 13"}
    };

    // Datos modificables que se inicializan con los predeterminados
    private String[][] datosModificables;

    public ActualizarCelular() {
        // Inicializamos los datos modificables con una copia de los predeterminados
        datosModificables = new String[datosPredeterminados.length][];
        for (int i = 0; i < datosPredeterminados.length; i++) {
            datosModificables[i] = datosPredeterminados[i].clone();
        }

        // Configuramos la ventana
        setTitle("Actualizar Celular");
        setSize(400, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null); // Esto nos permite colocar los componentes donde queramos

        // T�tulo de la ventana
        JLabel titulo = new JLabel("Actualizaci�n de celular");
        titulo.setFont(titulo.getFont().deriveFont(20f)); // Tama�o m�s grande para el t�tulo
        titulo.setBounds(80, 20, 250, 30); // Posici�n y tama�o
        add(titulo);

        // Etiqueta y ComboBox para seleccionar el modelo
        JLabel lblModelo = new JLabel("Modelo:");
        lblModelo.setBounds(30, 70, 100, 25);
        add(lblModelo);

        comboModelos = new JComboBox<>();
        comboModelos.setBounds(140, 70, 200, 25);
        add(comboModelos);

        // Llenamos el ComboBox con los nombres de los modelos
        for (String[] celular : datosPredeterminados) {
            comboModelos.addItem(celular[0]); // Agregamos solo el nombre del modelo
        }

        // Configuramos los campos de texto y etiquetas
        JLabel lblPrecio = new JLabel("Precio:");
        lblPrecio.setBounds(30, 110, 100, 25);
        add(lblPrecio);
        txtPrecio = new JTextField();
        txtPrecio.setBounds(140, 110, 200, 25);
        add(txtPrecio);

        JLabel lblPantalla = new JLabel("Pantalla:");
        lblPantalla.setBounds(30, 150, 100, 25);
        add(lblPantalla);
        txtPantalla = new JTextField();
        txtPantalla.setBounds(140, 150, 200, 25);
        add(txtPantalla);

        JLabel lblRam = new JLabel("RAM:");
        lblRam.setBounds(30, 190, 100, 25);
        add(lblRam);
        txtRam = new JTextField();
        txtRam.setBounds(140, 190, 200, 25);
        add(txtRam);

        JLabel lblAlmacenamiento = new JLabel("Almacenamiento:");
        lblAlmacenamiento.setBounds(30, 230, 100, 25);
        add(lblAlmacenamiento);
        txtAlmacenamiento = new JTextField();
        txtAlmacenamiento.setBounds(140, 230, 200, 25);
        add(txtAlmacenamiento);

        JLabel lblBateria = new JLabel("Bater�a:");
        lblBateria.setBounds(30, 270, 100, 25);
        add(lblBateria);
        txtBateria = new JTextField();
        txtBateria.setBounds(140, 270, 200, 25);
        add(txtBateria);

        JLabel lblCamara = new JLabel("C�mara:");
        lblCamara.setBounds(30, 310, 100, 25);
        add(lblCamara);
        txtCamara = new JTextField();
        txtCamara.setBounds(140, 310, 200, 25);
        add(txtCamara);

        JLabel lblSO = new JLabel("Sistema Operativo:");
        lblSO.setBounds(30, 350, 150, 25);
        add(lblSO);
        txtSO = new JTextField();
        txtSO.setBounds(140, 350, 200, 25);
        add(txtSO);

        // Bot�n para actualizar los datos
        btnActualizar = new JButton("Actualizar");
        btnActualizar.setBounds(70, 420, 120, 30);
        btnActualizar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String modeloSeleccionado = (String) comboModelos.getSelectedItem();

                for (int i = 0; i < datosModificables.length; i++) {
                    if (datosModificables[i][0].equals(modeloSeleccionado)) {
                        datosModificables[i][1] = txtPrecio.getText();
                        datosModificables[i][2] = txtPantalla.getText();
                        datosModificables[i][3] = txtRam.getText();
                        datosModificables[i][4] = txtAlmacenamiento.getText();
                        datosModificables[i][5] = txtBateria.getText();
                        datosModificables[i][6] = txtCamara.getText();
                        datosModificables[i][7] = txtSO.getText();
                        break;
                    }
                }
                JOptionPane.showMessageDialog(null, "Datos actualizados correctamente.", "�xito", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        add(btnActualizar);

        // Bot�n para cerrar la ventana
        btnCerrar = new JButton("Cerrar");
        btnCerrar.setBounds(210, 420, 120, 30);
        btnCerrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });
        add(btnCerrar);

        // Mostramos los datos iniciales del primer modelo seleccionado
        comboModelos.setSelectedIndex(0);
        cargarDatosEnCampos(0);

        // Listener para cambiar los datos mostrados seg�n el modelo seleccionado
        comboModelos.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int index = comboModelos.getSelectedIndex();
                cargarDatosEnCampos(index);
            }
        });
    }

    // M�todo para cargar los datos en los campos de texto
    private void cargarDatosEnCampos(int index) {
        txtPrecio.setText(datosModificables[index][1]);
        txtPantalla.setText(datosModificables[index][2]);
        txtRam.setText(datosModificables[index][3]);
        txtAlmacenamiento.setText(datosModificables[index][4]);
        txtBateria.setText(datosModificables[index][5]);
        txtCamara.setText(datosModificables[index][6]);
        txtSO.setText(datosModificables[index][7]);
    }

    // M�todo principal para probar la ventana
    public static void main(String[] args) {
        ActualizarCelular ventana = new ActualizarCelular();
        ventana.setVisible(true);
    }
}